import random

class Game:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, "_initialized"):
            self._initialized = True
            self._player1 = Knight()
            self._player2 = Knight()

    def reset_game(self):
        self._player1 = Knight()
        self._player2 = Knight()

    @property
    def player1(self):
        return self._player1

    @property
    def player2(self):
        return self._player2


class Character:
    def __init__(self, name, hp, atk):
        self._name = name
        self._hp = hp
        self._atk = atk

    @property
    def name(self):
        return self._name

    @property
    def hp(self):
        return self._hp

    @property
    def atk(self):
        return self._atk

    def take_damage(self, amount):
        self._hp = max(0, self._hp - amount)

    def is_alive(self):
        return self._hp > 0


class Knight(Character):
    def __init__(self):
        super().__init__("Knight", hp=100, atk=20)


def action(player1, action1, player2, action2):

    if action1 == "dodge":
        if action2 == "attack":
            damage = player2.atk
            if random.random() < 0.70:
                return f"{player1.name} dodges successfully!"
            else:
                player1.take_damage(damage)
                return f"{player1.name} tries to dodge but fails, taking {damage} damage!"
        elif action2 == "charged attack":
            damage = int(player2.atk * 1.5)
            if random.random() < 0.70:
                return f"{player1.name} dodges successfully!"
            else:
                player1.take_damage(damage)
                return f"{player1.name} tries to dodge but fails, taking {damage} damage!"
        else:
            return f"Both actions are nonattacks!"

    if action1 == "block":
        if action2 == "attack":
            damage = player2.atk // 2
            player1.take_damage(damage)
            return f"{player2.name} attacks! {player1.name} blocks, taking {damage} damage."
        elif action2 == "charged attack":
            damage = int(player2.atk * 1.5)
            player1.take_damage(damage)
            return f"{player2.name} uses a CHARGED ATTACK! {player1.name} blocks but still takes {damage} damage!"
        else:
            return f"Both actions are nonattacks!"

    if action1 == "attack":
        if action2 == "block":
            damage = player1.atk // 2
            player2.take_damage(damage)
            return f"{player1.name} attacks! {player2.name} blocks, taking {damage} damage."
        elif action2 == "dodge":
            damage = player1.atk
            if random.random() < 0.70:
                return f"{player2.name} dodges successfully!"
            else:
                player2.take_damage(damage)
                return f"{player2.name} tries to dodge but fails, taking {damage} damage!" 
        elif action2 == "attack":
            damage1 = player1.atk 
            damage2 = player2.atk
            player1.take_damage(damage2)
            player2.take_damage(damage1)
            return f"{player1.name} and {player2.name} attack, {player1.name} takes {damage2} damage and {player2.name} takes {damage1} damage."
        elif action2 == "charged attack":
            damage1 = player1.atk 
            damage2 = int(player2.atk * 1.5)
            player1.take_damage(damage2)
            player2.take_damage(damage1)
            return f"{player1.name} and {player2.name} attack, {player1.name} takes {damage2} damage and {player2.name} takes {damage1} damage."

    if action1 == "charged attack":
        if action2 == "block":
            damage = int(player1.atk * 1.5)
            player2.take_damage(damage)
            return f"{player1.name} uses a CHARGED ATTACK! {player2.name} blocks but still takes {damage} damage!"
        elif action2 == "dodge":
            damage = int(player1.atk * 1.5)
            if random.random() < 0.70:
                return f"{player2.name} dodges successfully!"
            else:
                player2.take_damage(damage)
                return f"{player2.name} tries to dodge but fails, taking {damage} damage!"
        elif action2 == "attack":
            damage1 = int(player1.atk * 1.5)
            damage2 = player2.atk
            player1.take_damage(damage2)
            player2.take_damage(damage1)
            return f"{player1.name} and {player2.name} attack, {player1.name} takes {damage2} damage and {player2.name} takes {damage1} damage."
        elif action2 == "charged attack":
            damage1 = int(player1.atk * 1.5)
            damage2 = int(player2.atk * 1.5)
            player1.take_damage(damage2)
            player2.take_damage(damage1)
            return f"{player1.name} and {player2.name} attack, {player1.name} takes {damage2} damage and {player2.name} takes {damage1} damage."
    return ""


def main():
    gm = Game()
    actions = ["attack", "block", "charged attack", "dodge"]

    while True:
        player1 = gm.player1
        player2 = gm.player2

        while player1.is_alive() and player2.is_alive():

            print(f"\nP1 {player1.name} HP: {player1.hp} | P2 {player2.name} HP: {player2.hp}")

            action1 = input(f"Player 1, choose an action {actions}: ").lower()
            while action1 not in actions:
                action1 = input(f"Invalid! Choose {actions}: ").lower()

            action2 = input(f"Player 2, choose an action {actions}: ").lower()
            while action2 not in actions:
                action2 = input(f"Invalid! Choose {actions}: ").lower()

            print(action(player1, action1, player2, action2))

        if not player1.is_alive() and not player2.is_alive():
            print("\nNo one wins!")
        elif player1.is_alive():
            print("\nPlayer 1 wins!")
        elif player2.is_alive():
            print("\nPlayer 2 wins!")

        print("\nRestarting game...")
        gm.reset_game()

if __name__ == "__main__":
    main()